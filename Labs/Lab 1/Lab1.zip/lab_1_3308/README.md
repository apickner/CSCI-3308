# lab_1_3308
Lab 1: Software Development and Tools (This is not my first repo)
---
    So I initially tried getting the VM environment setup, but I messed up
while trying to get Guest Additions installed. I will more than likely try to get it up and running as I like Linux and it may come in handy later on in the semester.

    However, I was able to get my repo up on Github. I also already had git  
installed on my Mac, and I was able to push a commit to the web. Next, using
homebrew (an Apple alternative to apt-get) I was able to make sure I have Node
and Postgresql installed and functional. I also have an environment to work on
React as well, and I have knowledge in HTML and some style languages as well so
I think my web development will be fine on my Mac.
